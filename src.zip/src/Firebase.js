// data

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const database = getFirestore(app)
const db = getFirestore(app); 
export { auth, provider, database, db }; 
