const dummyUsers = [
  {
    displayName: "Ananya",
    email: "ananyanarang1411@gmail.com",
    password: "1234",
    phone: "9810820774",
    dailyGoal: 1800,
    alarmEnabled: true,
  },
  {
    displayName: "Ananya 2",
    email: "ananya.narang2024@nst.rishihood.edu.in",
    password: "5678",
    phone: "1234567899",
    dailyGoal: 3500,
    alarmEnabled: true,
  },
  {
    displayName: "Neha",
    email: "knarang383@gmail.com",
    password: "abcd",
    phone: "9432114567",
    dailyGoal: 2000,
    alarmEnabled: true,
  },
];

export default dummyUsers;
