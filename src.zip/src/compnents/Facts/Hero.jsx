import React from 'react'
import './Hero.css'

const Hero = () => {
  return (
    <div className='hero1'>
        <div className='text2'>
            <h1>Hydration facts — Everything you need to know to stay hydrated</h1>

        </div>


    </div>
  )
}

export default Hero